# ShareMe Social Media Application
![ShareMe](https://i.ibb.co/8cLfj3X/image.png)

## Introduction
This is a code repository for the corresponding video tutorial.

Using React, Tailwind & Sanity you'll learn how to build a Full Stack Social Media Application - from start to finish.

## Stay up to date with new projects
New major projects coming soon, subscribe to the mailing list to stay up to date https://jsmasterypro.com/newsletter
